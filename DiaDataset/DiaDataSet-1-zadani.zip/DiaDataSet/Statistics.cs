﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DiaDataSet
{
    public static class Statistics
    {
        // PersonsByMaxGlucose (List<Person> data)
        
        // WhoHasMaxGlucose(List<Person> data)
        
    }
}
